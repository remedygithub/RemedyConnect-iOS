//
//  PushIOCustomTracker.h
//  PushIOManager
//
//  Copyright (c) 2013 Push IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PushIOManager+PushIOTrackers.h"

@interface PushIOCustomTracker: PushIOTracker

@end
