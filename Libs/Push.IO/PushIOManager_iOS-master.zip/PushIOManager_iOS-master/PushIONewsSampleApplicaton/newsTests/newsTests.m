//
//  newsTests.m
//  newsTests
//
//  Created by Dan Burcaw on 7/26/12.
//  Copyright (c) 2013 Push IO Inc. All rights reserved.
//

#import "newsTests.h"

@implementation newsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
}

@end
