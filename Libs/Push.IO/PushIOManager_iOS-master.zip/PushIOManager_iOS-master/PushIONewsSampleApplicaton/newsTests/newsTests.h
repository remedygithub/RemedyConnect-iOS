//
//  newsTests.h
//  newsTests
//
//  Created by Dan Burcaw on 7/26/12.
//  Copyright (c) 2013 Push IO Inc. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface newsTests : SenTestCase

@end
