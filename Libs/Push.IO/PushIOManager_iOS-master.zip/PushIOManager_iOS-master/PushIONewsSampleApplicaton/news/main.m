//
//  main.m
//  news
//
//  Created by Dan Burcaw on 7/26/12.
//  Copyright (c) 2012 Push IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PushIONewsAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PushIONewsAppDelegate class]));
    }
}
